# Waterstrider simulation
## Launch robot
Setup source:
```bash
source /opt/ros/iron/setup.bash
source $HOME/ros2_ws/install/setup.bash
source /usr/share/gazebo/setup.sh
```
Launch an ocean world (Plankton package):
```bash
ros2 launch uuv_gazebo_worlds lake.launch
```
Launch a robot in the world
```bash
ros2 launch waterstridergazebo upload_waterstrider_launch.py
```
## Teleoperation
Launch thrusters controller for any type of teleoperation
```bash
ros2 launch waterstridergazebo thrusters_controller_launch.py 
```
Keyboard teleoperation
```bash
ros2 run teleop_twist_keyboard teleop_twist_keyboard --ros-args --remap cmd_vel:=waterstrider/twist_command
```
Joystick teleoperation
```bash
ros2 launch waterstridergazebo joy_teleop.launch
```