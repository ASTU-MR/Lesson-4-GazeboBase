#include <rclcpp/rclcpp.hpp>

#include <eigen3/Eigen/Core>
#include <eigen3/Eigen/Eigen>
#include <eigen3/Eigen/SVD>

#include <std_msgs/msg/float64.hpp>
#include <uuv_gazebo_ros_plugins_msgs/msg/float_stamped.hpp>
#include <geometry_msgs/msg/wrench.hpp>
#include <geometry_msgs/msg/twist.hpp>

using std::placeholders::_1;

using Eigen::Vector3d;
using Eigen::VectorXd;
using Eigen::MatrixXd;
typedef Eigen::Matrix<double,6,1> RowVector6d;
typedef rclcpp::Publisher<uuv_gazebo_ros_plugins_msgs::msg::FloatStamped, std::allocator<void>> ThrusterPublisherT;

class Thruster
{
public:
    Thruster(std::shared_ptr<ThrusterPublisherT> pub, bool enabled, std::vector<double> &f, std::vector<double> &r, const std::vector<double> &input, const std::vector<double> &output)
        : publisher(pub),
          enabled(enabled)
    {
        assert(input.size() == output.size());
        assert(f.size() == 3);
        assert(r.size() == 3);

        setf(f);
        setr(r);
        setLookupTable(input, output);
    }

    void publish(double cmd)
    {
        uuv_gazebo_ros_plugins_msgs::msg::FloatStamped msg;
        msg.data = this->convert(cmd);
        this->publisher->publish(msg);
    }

    void setEnabled(bool enabled) { this->enabled = enabled; }
    void setf(std::vector<double> &f) { this->f = Vector3d(f[0], f[1], f[2]); }
    void setr(std::vector<double> &r) { this->r = Vector3d(r[0], r[1], r[2]); }
    void setLookupTable(const std::vector<double> &input, const std::vector<double> &output)
    {
        lookupTable.clear();
        size_t len = std::min(input.size(), output.size());
        for (size_t i = 0; i < len; i++)
          lookupTable[input[i]] = output[i];
    }

    bool isEnabled() { return  enabled; }
    Vector3d getf() { return f; }
    Vector3d getr() { return r; }

private:
    double convert(double cmd)
    {
        assert(!lookupTable.empty());

        // "first element whose key is NOT considered to go before cmd"
        auto iter = lookupTable.lower_bound(cmd);

        if (iter == lookupTable.end())
        {
          // "all keys are considered to go before"
          // last element is closest
          return lookupTable.rbegin()->second;
        }

        double i1 = iter->first;
        double o1 = iter->second;

        if (iter == lookupTable.begin())
          return o1;

        iter--;

        double i0 = iter->first;
        double o0 = iter->second;

        double w1 = cmd - i0;
        double w0 = i1 - cmd;

        return (o0*w0 + o1*w1)/(w0 + w1);

    }

    std::shared_ptr<ThrusterPublisherT> publisher;

    std::map<double, double> lookupTable;
    bool enabled;
    Vector3d f;
    Vector3d r;
};

class ThrusterController : public rclcpp::Node
{
public:
    ThrusterController()
        : Node("thrusters_controller")
    {
        for (auto &o : this->get_node_parameters_interface()->get_parameter_overrides())
        {
            std::istringstream iss(o.first);
            std::string token;
            std::getline(iss, token, '.');
            if (token == "thrusters")
            {
                std::getline(iss, token, '.');
                thrusters_map_[token] = nullptr;
            }
        }

        thrusters_vec_.reserve(thrusters_map_.size());
        for (auto &t : thrusters_map_)
        {
            bool enabled = declare_parameter<bool>("thrusters." + t.first + ".enabled");

            std::vector<double> f = declare_parameter<std::vector<double>>("thrusters." + t.first + ".f");
            assert(f.size() == 3);

            std::vector<double> r = declare_parameter<std::vector<double>>("thrusters." + t.first + ".r");
            assert(r.size() == 3);

            std::vector<double> input = declare_parameter<std::vector<double>>("thrusters." + t.first + ".input");
            std::vector<double> output = declare_parameter<std::vector<double>>("thrusters." + t.first + ".output");

            auto pub = this->create_publisher<uuv_gazebo_ros_plugins_msgs::msg::FloatStamped>("thrusters/" + t.first, 1);

            t.second = new Thruster(pub, enabled, f, r, input, output);

            RCLCPP_INFO(this->get_logger(), "ADDED THRUSTER: %s", t.first.c_str());
            RCLCPP_INFO_STREAM(this->get_logger(), "enabled: " << enabled << "; f: " << f[0] << " " << f[1] << " " << f[2] << "; r: " << r[0] << " " << r[1] << " " << r[2]);
        }
        calculateTam_();

        wrench_subscription_ = this->create_subscription<geometry_msgs::msg::Wrench>(
                    "wrench_command", 10, std::bind(&ThrusterController::wrench_callback, this, _1));
        twist_subscription_ = this->create_subscription<geometry_msgs::msg::Twist>(
                    "twist_command", 10, std::bind(&ThrusterController::twist_callback, this, _1));

        callback_handle_ = this->add_on_set_parameters_callback(
            std::bind(&ThrusterController::parametersCallback, this, std::placeholders::_1));
    }

    rcl_interfaces::msg::SetParametersResult parametersCallback(
        const std::vector<rclcpp::Parameter> &parameters)
    {
        rcl_interfaces::msg::SetParametersResult result;
        result.successful = true;
        result.reason = "success";

        for (auto &p : parameters)
        {
            RCLCPP_INFO(this->get_logger(), "Setting parameter: %s", p.get_name().c_str());

            std::istringstream iss(p.get_name());
            std::string parameter_name;
            std::getline(iss, parameter_name, '.');
            if (parameter_name == "thrusters")
            {
                std::string thruster_name;
                std::getline(iss, thruster_name, '.');
                if (Thruster *t = thrusters_map_[thruster_name])
                {
                    std::getline(iss, parameter_name, '.');
                    if (parameter_name == "enabled")
                    {
                        t->setEnabled(p.get_parameter_value().get<bool>());
                        calculateTam_();
                    }
                    else if (parameter_name == "f")
                    {
                        auto f = p.get_parameter_value().get<std::vector<double>>();
                        if (f.size() != 3)
                        {
                            result.successful = false;
                            result.reason = "f vector for thruster" + thruster_name + " size != 3";
                            return result;
                        }
                        t->setf(f);
                        calculateTam_();
                    }
                    else if (parameter_name == "r")
                    {
                        auto r = p.get_parameter_value().get<std::vector<double>>();
                        if (r.size() != 3)
                        {
                            result.successful = false;
                            result.reason = "r vector for thruster" + thruster_name + " size != 3";
                            return result;
                        }
                        t->setr(r);
                        calculateTam_();
                    }
                    else if (parameter_name == "input")
                    {
                        std::vector<double> input = p.get_parameter_value().get<std::vector<double>>();
                        std::vector<double> output = get_parameter("thrusters." + thruster_name + ".output").get_value<std::vector<double>>();
                        t->setLookupTable(input, output);

                    }
                    else if (parameter_name == "output")
                    {
                        std::vector<double> input = get_parameter("thrusters." + thruster_name + ".input").get_value<std::vector<double>>();
                        std::vector<double> output = p.get_parameter_value().get<std::vector<double>>();
                        t->setLookupTable(input, output);
                    }
                }
            }
        }

        return result;
    }

private:
    void wrench_callback(const geometry_msgs::msg::Wrench::SharedPtr msg)
    {
        RowVector6d wrench = readWrench_(msg);
        VectorXd effort = tam_ * wrench;

        for(unsigned i = 0; i < tam_.rows(); ++i)
            thrusters_vec_[i]->publish(effort[i]);
    }

    void twist_callback(const geometry_msgs::msg::Twist::SharedPtr msg)
    {
        RowVector6d wrench = readTwist_(msg);
        VectorXd effort = tam_ * wrench;

        for(unsigned i = 0; i < tam_.rows(); ++i)
            thrusters_vec_[i]->publish(effort[i]);
    }

    void calculateTam_()
    {
        thrusters_vec_.clear();
        for (auto it = thrusters_map_.cbegin(); it != thrusters_map_.cend(); ++it)
            thrusters_vec_.push_back(it->second);

        MatrixXd T(6, thrusters_vec_.size());
        RCLCPP_INFO_STREAM(this->get_logger(), "Calculating TAM; Thrusters count: " << thrusters_vec_.size());

        for(size_t i = 0; i < thrusters_vec_.size(); ++i)
        {
            Vector3d f = thrusters_vec_[i]->isEnabled() ? thrusters_vec_[i]->getf() : Vector3d(0, 0, 0);
            Vector3d r = thrusters_vec_[i]->getr();
            T.col(i) << f, r.cross(f);
        }

        tam_ = pseudoInverse(T);

        RCLCPP_INFO_STREAM(this->get_logger(), "T\n" << T);
        RCLCPP_INFO_STREAM(this->get_logger(), "Inverse T:\n" << tam_);
    }

    RowVector6d readWrench_(const geometry_msgs::msg::Wrench::SharedPtr msg)
    {
        RowVector6d wrench;

        wrench[0] = msg->force.x;
        wrench[1] = msg->force.y;
        wrench[2] = msg->force.z;
        wrench[3] = msg->torque.x;
        wrench[4] = msg->torque.y;
        wrench[5] = msg->torque.z;

        return wrench;
    }

    RowVector6d readTwist_(const geometry_msgs::msg::Twist::SharedPtr msg)
    {
        RowVector6d wrench;

        wrench[0] = msg->linear.x;
        wrench[1] = msg->linear.y;
        wrench[2] = msg->linear.z;
        wrench[3] = msg->angular.x;
        wrench[4] = msg->angular.y;
        wrench[5] = msg->angular.z;

        return wrench;
    }

    template<typename _Matrix_Type_>
    _Matrix_Type_ pseudoInverse(const _Matrix_Type_ &a, double epsilon = std::numeric_limits<double>::epsilon())
    {
        Eigen::JacobiSVD<_Matrix_Type_> svd(a, Eigen::ComputeThinU | Eigen::ComputeThinV);
        double tolerance = epsilon * std::max(a.cols(), a.rows()) * svd.singularValues().array().abs()(0);
        return svd.matrixV() * (svd.singularValues().array().abs() > tolerance).select(svd.singularValues().array().inverse(), 0).matrix().asDiagonal() * svd.matrixU().adjoint();
    }

    MatrixXd tam_;
    std::vector<Thruster *> thrusters_vec_;
    std::map<std::string, Thruster *> thrusters_map_;
    rclcpp::Subscription<geometry_msgs::msg::Wrench>::SharedPtr wrench_subscription_;
    rclcpp::Subscription<geometry_msgs::msg::Twist>::SharedPtr twist_subscription_;
    OnSetParametersCallbackHandle::SharedPtr callback_handle_;
};


int main(int argc, char **argv)
{
    rclcpp::init(argc, argv);
    rclcpp::spin(std::make_shared<ThrusterController>());
    rclcpp::shutdown();
    return 0;
}
