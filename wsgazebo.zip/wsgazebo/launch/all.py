import os

from ament_index_python import get_package_share_directory

from launch import LaunchDescription
from launch.actions import GroupAction, IncludeLaunchDescription
from launch_ros.actions import Node, PushRosNamespace
                                    
from launch_xml.launch_description_sources import XMLLaunchDescriptionSource
from launch.launch_description_sources import PythonLaunchDescriptionSource

def generate_launch_description():
    ld = LaunchDescription()

    gazebo = IncludeLaunchDescription(XMLLaunchDescriptionSource(os.path.join(get_package_share_directory('uuv_gazebo_worlds'), 'launch/ocean_waves.launch')))
    ld.add_action(gazebo)

    waterstider = IncludeLaunchDescription(PythonLaunchDescriptionSource(os.path.join(get_package_share_directory('waterstridergazebo'), 'launch/upload_waterstrider_launch.py')))
    ld.add_action(waterstider)

    thruster_controller = IncludeLaunchDescription(PythonLaunchDescriptionSource(os.path.join(get_package_share_directory('waterstridergazebo'), 'launch/thrusters_controller_launch.py')))
    ld.add_action(thruster_controller)

    return ld