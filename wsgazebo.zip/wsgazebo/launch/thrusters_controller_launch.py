import os

from ament_index_python import get_package_share_directory

from launch import LaunchDescription
from launch.actions import GroupAction
from launch_ros.actions import Node, PushRosNamespace


def generate_launch_description():
    group = GroupAction([
        PushRosNamespace('waterstrider'),
        Node(
            package='waterstridergazebo',
            executable='thrusters_controller_node',
            output='screen',
            parameters=[os.path.join(
                get_package_share_directory('waterstridergazebo'),
                'config',
                'waterstrider_thrusters.yaml'
            )],
            remappings=[
                ('/waterstrider/thrusters/controller_output_0', '/waterstrider/thrusters/id_0/input'),
                ('/waterstrider/thrusters/controller_output_1', '/waterstrider/thrusters/id_1/input'),
            ]
        )
        ])
    return LaunchDescription([
        group
    ])
